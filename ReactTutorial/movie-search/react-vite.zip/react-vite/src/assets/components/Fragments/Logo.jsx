const Logo = () => {
    return (
      <div className="text-2xl font-bold text-red-600">
        NontonKuy
      </div>
    );
  };
  
  export default Logo;